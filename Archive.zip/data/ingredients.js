const mongoCollections = require("../config/mongoCollections");
const ingredients = mongoCollections.ingredients;
let { ObjectId } = require("mongodb");
const helper = require("./helper");

module.exports = {
  async create({ name, category, protien, carb, fat }) {
    helper.checkProperString(name, "Ingredient Name");
    helper.checkProperString(category, "Ingredient Category");
    helper.checkProperNumber(protien, "Protien");
    helper.checkProperNumber(carb, "Carbs");
    helper.checkProperNumber(fat, "Fats");
    if (protien < 0 || carb < 0 || fat < 0)
      throw "Nutritional info cannot be negative";
    const ingredientCollection = await ingredients();
    let newIngredient = {
      name: name,
      category: category,
      protien: protien,
      carb: carb,
      fat: fat,
      userGenerated: false,
    };
    const insertInfo = await ingredientCollection.insertOne(newIngredient);
    if (insertInfo.insertedCount === 0)
      throw `Could not create the Ingredient ${name}`;
    const newId = insertInfo.insertedId.toString();
    const ingredient = await this.get(newId);
    return ingredient;
  },

  async createByUser({ name, category }) {
    helper.checkProperString(name, "Ingredient Name");
    helper.checkProperString(category, "Ingredient Category");
    const ingredientCollection = await ingredients();
    let newIngredient = {
      name: name,
      category: category,
      protien: 0,
      carb: 0,
      fat: 0,
      userGenerated: true,
    };
    const insertInfo = await ingredientCollection.insertOne(newIngredient);
    if (insertInfo.insertedCount === 0)
      throw `Could not create the Ingredient ${name}`;
    const newId = insertInfo.insertedId.toString();
    const ingredient = await this.get(newId);
    return ingredient;
  },

  async get(id) {
    helper.checkProperString(id, "Ingredient ID");
    if (!ObjectId.isValid(id)) throw "Error: Not a valid ObjectId";
    let ID = ObjectId(id);
    const ingredientCollection = await ingredients();

    const ingredient = await ingredientCollection.findOne({ _id: ID });
    if (ingredient === null) {
      throw "Error: No ingredient with that id";
    }
    ingredient._id = ingredient._id.toString();
    return ingredient;
  },

  async getAll() {
    const ingredientCollection = await ingredients();
    const ingredientList = await ingredientCollection.find({}).toArray();
    const categories = [
      ...new Set(ingredientList.map((item) => item.category)),
    ];
    let categorizedIngredients = {};
    for (const category of categories) {
      categorizedIngredients[category] = ingredientList
        .filter((x) => x.category === category)
        .map((y) => y.name);
    }
    return categorizedIngredients;
  },

  async remove(id) {
    helper.checkProperString(id, "Ingredient ID");
    if (!ObjectId.isValid(id)) throw "Error: Not a valid ObjectId";
    let ID = ObjectId(id);

    const ingredientCollection = await ingredients();

    const deletionInfo = await ingredientCollection.deleteOne({ _id: ID });

    if (deletionInfo.deletedCount === 0) {
      throw `Error: Could not delete ingredient with id of ${ID}`;
    }
    return { ingredientId: id, deleted: true };
  },

  async update(id, name) {
    helper.checkProperString(name, "Name");
    if (!ObjectId.isValid(id)) throw "Error: Not a valid ObjectId";

    const ingredient = await this.get(id);
    let ID = ObjectId(id);

    let updatedIngredient = {
      name: name,
    };

    const ingredientCollection = await ingredients();
    const updateInfo = await ingredientCollection.updateOne(
      { _id: ID },
      { $set: updatedIngredient }
    );
    if (!updateInfo.matchedCount && !updateInfo.modifiedCount)
      throw "Update failed";
    const ingredientn = await this.get(id);

    return ingredientn;
  },

  async modifyingNuValue(ingredientId) {
    //
  },

  async addNuValue(ingredientId, reviewId, reviewobj) {
    //add Nu Value
  },

  async removeNuValue(ingredientId, reviewId) {
    //remove nuValue
  },
};

const restaurantRoutes = require("./recipes");
const reviewRoutes = require("./reviews");
const userRoutes = require("./users");
const commentRoutes = require("./comments");
const ingreientsRoutes = require("./ingredients");

const constructorMethod = (app) => {
  app.use("/reviews", reviewRoutes);
  // app.use("/users", userRoutes);
  // app.use("/comments", commentRoutes);
  app.use("/ingredients", ingreientsRoutes);
  app.use("/", (req, res) => {
    res.render("home");
  });
  app.use("*", (req, res) => {
    res.status(404).json({ error: "Page not found" });
  });
};

module.exports = constructorMethod;
